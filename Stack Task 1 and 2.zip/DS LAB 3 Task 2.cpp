#include <iostream>
using namespace std;

template <typename t>
class abstractstack {
public:
    virtual void push(t value) = 0;
    virtual t pop() = 0;
    virtual t top() const = 0;
    virtual bool isempty() const = 0;
    virtual bool isfull() const = 0;
    virtual ~abstractstack() {}
};

template <typename t>
class mystack : public abstractstack<t>
{
private:
    t* arr;
    t* minarr;
    int topindex;
    int mintop;
    int maxsize;

public:
    mystack(int size)
    {
        maxsize = size;
        arr = new t[maxsize];
        minarr = new t[maxsize];
        topindex = -1;
        mintop = -1;
    }

    ~mystack()
    {
        delete[] arr;
        delete[] minarr;
    }

    void push(t value)
    {
        if (isfull())
        {
            cout << "stack overflow" << endl;
            return;
        }

        arr[++topindex] = value;

        if (mintop == -1 || value <= minarr[mintop])
        {
            minarr[++mintop] = value;
        }
    }

    t pop()
    {
        if (isempty()) 
        {
            cout << "stack underflow" << endl;
            return -1;
        }

        t val = arr[topindex--];

        if (val == minarr[mintop]) {
            mintop--;
        }

        return val;
    }

    t top() const 
    {
        if (isempty()) 
        {
            cout << "stack empty" << endl;
            return -1;
        }
        return arr[topindex];
    }

    bool isempty() const
    {
        return topindex == -1;
    }

    bool isfull() const 
    {
        return topindex == maxsize - 1;
    }

    t getmin() const
    {
        if (mintop == -1)
        {
            cout << "stack empty" << endl;
            return -1;
        }
        return minarr[mintop];
    }

    void display() const 
    {
        if (isempty())
        {
            cout << "stack empty" << endl;
            return;
        }
        for (int i = topindex; i >= 0; i--)
        {
            cout << arr[i] << endl;
        }
    }
};

int main() 
{
    int size;
    cout << "Enter Size";
    cin >> size;

    mystack<int> s(size);

    int choice, value;

    do {
        cout << "1 push " << endl;
        cout << "2 pop " << endl;
        cout << "3 show top " << endl;
        cout << "4 check empty" << endl;
        cout << "5 check full" << endl;
        cout << "6 display " << endl;
        cout << "7 show minimum element" << endl;
        cout << "0 exit" << endl;

        cin >> choice;

        switch (choice) 
        {
        case 1:
            cin >> value;
            s.push(value);
            break;
        case 2:
            cout << s.pop() << endl;
            break;
        case 3:
            cout << s.top() << endl;
            break;
        case 4:
            if (s.isempty())
            {
                cout << "Yes";
            }
            else
                cout << "NO";
            break;
        case 5:
            if (s.isfull())
            {
                cout << "Yes";
            }
            else
                cout << "NO";
            break;
        case 6:
            s.display();
            break;
        case 7:
            cout << s.getmin() << endl;
            break;
        }
    } while (choice != 0);

    return 0;
}