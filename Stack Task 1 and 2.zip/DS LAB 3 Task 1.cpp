#include <iostream>
using namespace std;

template <typename t>
class abstractstack {
public:
    virtual void push(t value) = 0;
    virtual t pop() = 0;
    virtual t top() const = 0;
    virtual bool isempty() const = 0;
    virtual bool isfull() const = 0;
    virtual ~abstractstack() {}
};

template <typename t>
class mystack : public abstractstack<t>
{
private:
    t* arr;
    int topindex;
    int maxsize;

public:
    mystack(int size) 
    {
        maxsize = size;
        arr = new t[maxsize];
        topindex = -1;
    }

    ~mystack()
    {
        delete[] arr;
    }

    void push(t value)
    {
        if (isfull())
        {
            cout << "stack overflow" << endl;
            return;
        }
        arr[++topindex] = value;
    }

    t pop()
    {
        if (isempty())
        {
            cout << "stack underflow" << endl;
            return -1;
        }
        return arr[topindex--];
    }

    t top() const
    {
        if (isempty())
        {
            cout << "stack empty" << endl;
            return -1;
        }
        return arr[topindex];
    }

    bool isempty() const
    {
        return topindex == -1;
    }

    bool isfull() const 
    {
        return topindex == maxsize - 1;
    }

    void display() const
    {
        if (isempty())
        {
            cout << "stack empty" << endl;
            return;
        }
        for (int i = topindex; i >= 0; i--)
        {
            cout << arr[i] << endl;
        }
    }
};

int main()
{
    int size;
    cout << "Enter Size:";
    cin >> size;

    mystack<int> s(size);

    int choice, value;

    do {
        cout << "1 push" << endl;
        cout << "2 pop" << endl;
        cout << "3 top" << endl;
        cout << "4 isempty" << endl;
        cout << "5 isfull" << endl;
        cout << "6 display" << endl;
        cout << "0 exit" << endl;

        cin >> choice;

        switch (choice) {
        case 1:
            cin >> value;
            s.push(value);
            break;
        case 2:
            cout << s.pop() << endl;
            break;
        case 3:
            cout << s.top() << endl;
            break;
        case 4:
            if (s.isempty())
            {
                cout << "Yes";
            }
            else
                cout << "NO";
            break;
        case 5:
            if (s.isfull())
            {
                cout << "Yes";
            }
            else
                cout << "NO";
            break;
        case 6:
            s.display();
            break;
        }
    } while (choice != 0);

    return 0;
}