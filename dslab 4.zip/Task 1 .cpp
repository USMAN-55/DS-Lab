#include <iostream>
using namespace std;

template <typename t>
class abstractqueue {
public:
    virtual void enqueue(t v) = 0;
    virtual t dequeue() = 0;
    virtual t front() const = 0;
    virtual bool isempty() const = 0;
    virtual bool isfull() const = 0;
    virtual ~abstractqueue() {}
};

template <typename t>
class myqueue : public abstractqueue<t> {
    t* arr;
    int f, r, s, top;

public:
    myqueue(int c) {
        top = c;
        arr = new t[top];
        f = 0;
        r = -1;
        s = 0;
    }

    void enqueue(t v) {
        if (isfull()) {
            cout << "full\n";
            return;
        }
        r = (r + 1) % top;
        arr[r] = v;
        s++;
    }

    t dequeue() {
        if (isempty()) {
            cout << "empty\n";
            return -1;
        }
        t x = arr[f];
        f = (f + 1) % top;
        s--;
        return x;
    }

    t front() const {
        if (isempty()) {
            cout << "empty\n";
            return -1;
        }
        return arr[f];
    }

    bool isempty() const {
        return s == 0;
    }

    bool isfull() const {
        return s == top;
    }

    void display() const {
        if (isempty()) {
            cout << "empty\n";
            return;
        }
        int i = f;
        for (int c = 0; c < s; c++) {
            cout << arr[i] << " ";
            i = (i + 1) % top;
        }
        cout << endl;
    }

    ~myqueue() {
        delete[] arr;
    }
};

int main() {
    int n;
    cout << "size: ";
    cin >> n;

    myqueue<int> q(n);

    int ch, v;

    do {
        cout << "\n1 enq\n2 deq\n3 front\n4 empty\n5 full\n6 display\n0 exit\n";
        cin >> ch;

        if (ch == 1) {
            cin >> v;
            q.enqueue(v);
        }
        else if (ch == 2) {
            cout << q.dequeue() << endl;
        }
        else if (ch == 3) {
            cout << q.front() << endl;
        }
        else if (ch == 4) {
            cout << q.isempty() << endl;
        }
        else if (ch == 5) {
            cout << q.isfull() << endl;
        }
        else if (ch == 6) {
            q.display();
        }

    } while (ch != 0);

    return 0;
}