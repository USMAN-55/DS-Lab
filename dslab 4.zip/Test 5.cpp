#include <iostream>
#include <string>
using namespace std;

class q {
    string* arr;
    int f, r, s, size;

public:
    q(int n) {
        size = n;
        arr = new string[size];
        f = 0;
        r = -1;
        s = 0;
    }

    void enqueue(string v) {
        if (s == size) {
            cout << "full\n";
            return;
        }
        r = (r + 1) % size;
        arr[r] = v;
        s++;
    }

    string dequeue() {
        if (s == 0) {
            cout << "empty\n";
            return "";
        }
        string x = arr[f];
        f = (f + 1) % size;
        s--;
        return x;
    }

    string front() {
        if (s == 0) {
            cout << "empty\n";
            return "";
        }
        return arr[f];
    }

    void display() {
        if (s == 0) {
            cout << "empty\n";
            return;
        }
        int i = f;
        for (int c = 0; c < s; c++) {
            cout << arr[i] << " ";
            i = (i + 1) % size;
        }
        cout << endl;
    }
};

int main() {
    int n;
    cout << "size: ";
    cin >> n;

    q q1(n);

    int ch;
    string name;

    do {
        cout << "\n1 add\n2 print\n3 front\n4 display\n0 exit\n";
        cin >> ch;

        if (ch == 1) {
            cin >> name;
            q1.enqueue(name);
        }
        else if (ch == 2) {
            cout << q1.dequeue() << endl;
        }
        else if (ch == 3) {
            cout << q1.front() << endl;
        }
        else if (ch == 4) {
            q1.display();
        }

    } while (ch != 0);

    return 0;
}