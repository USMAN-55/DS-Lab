#include <iostream>
using namespace std;

class q {
    int* arr;
    int f, r, s, size;

public:
    q(int n) {
        size = n;
        arr = new int[size];
        f = 0;
        r = -1;
        s = 0;
    }

    void enqueue(int v) {
        if (s == size) {
            cout << "full\n";
            return;
        }
        r = (r + 1) % size;
        arr[r] = v;
        s++;
    }

    int dequeue() {
        if (s == 0) {
            cout << "empty\n";
            return -1;
        }
        int x = arr[f];
        f = (f + 1) % size;
        s--;
        return x;
    }

    int front() {
        if (s == 0) {
            cout << "empty\n";
            return -1;
        }
        return arr[f];
    }

    void display() {
        if (s == 0) {
            cout << "empty\n";
            return;
        }
        int i = f;
        for (int c = 0; c < s; c++) {
            cout << arr[i] << " ";
            i = (i + 1) % size;
        }
        cout << endl;
    }
};

int main() {
    int n;
    cout << "size: ";
    cin >> n;

    q q1(n);

    int ch, id;

    do {
        cout << "\n1 add\n2 resolve\n3 next\n4 display\n0 exit\n";
        cin >> ch;

        if (ch == 1) {
            cin >> id;
            if (id >= 1000 && id <= 9999)
                q1.enqueue(id);
            else
                cout << "invalid\n";
        }
        else if (ch == 2) {
            cout << q1.dequeue() << endl;
        }
        else if (ch == 3) {
            cout << q1.front() << endl;
        }
        else if (ch == 4) {
            q1.display();
        }

    } while (ch != 0);

    return 0;
}