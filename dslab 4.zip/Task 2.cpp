#include <iostream>
using namespace std;

class st {
    int* arr;
    int top, cap;

public:
    st(int c) {
        cap = c;
        arr = new int[cap];
        top = -1;
    }

    void push(int v) {
        if (top == cap - 1) return;
        arr[++top] = v;
    }

    int pop() {
        if (top == -1) return -1;
        return arr[top--];
    }

    int peek() {
        if (top == -1) return -1;
        return arr[top];
    }

    bool isempty() {
        return top == -1;
    }

    ~st() {
        delete[] arr;
    }
};

class q {
    st s1, s2;

public:
    q(int c) : s1(c), s2(c) {}

    void enq(int v) {
        s1.push(v);
    }

    int deq() {
        if (s2.isempty()) {
            while (!s1.isempty()) {
                s2.push(s1.pop());
            }
        }
        return s2.pop();
    }

    int front() {
        if (s2.isempty()) {
            while (!s1.isempty()) {
                s2.push(s1.pop());
            }
        }
        return s2.peek();
    }

    void display() {
        st t1 = s1;
        st t2 = s2;

        if (t2.isempty()) {
            while (!t1.isempty()) {
                t2.push(t1.pop());
            }
        }

        while (!t2.isempty()) {
            cout << t2.pop() << " ";
        }
        cout << endl;
    }
};

int main() {
    int n;
    cout << "size: ";
    cin >> n;

    q q1(n);

    int ch, v;

    do {
        cout << "\n1 enq\n2 deq\n3 front\n4 display\n0 exit\n";
        cin >> ch;

        if (ch == 1) {
            cin >> v;
            q1.enq(v);
        }
        else if (ch == 2) {
            cout << q1.deq() << endl;
        }
        else if (ch == 3) {
            cout << q1.front() << endl;
        }
        else if (ch == 4) {
            q1.display();
        }

    } while (ch != 0);

    return 0;
}