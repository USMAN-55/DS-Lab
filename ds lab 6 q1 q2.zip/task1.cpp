#include<iostream>
using namespace std;
class node
{
public:
	int data;
	node*next;
	

};
class list
{
private:
	node*head;
public:
	list()
	{
		head = NULL;
	}
	void insertdata(int d)
	{
		node* temp = new node;
		temp->data = d;
		temp->next = NULL;
		node* curr = head;
		if (head == NULL)
		{
			head = temp;
		}
		else
		{
			while (curr->next != NULL)
			{
				curr = curr->next;
			}
			curr->next = temp;
		}

		
	}
	void display()
	{
		node* curr = head;
		while (curr!= NULL)
		{
			cout << curr->data<< endl;
			curr = curr->next;
		}
	}
};
int main()
{
	int choice;
	list l;
	int d;
	do
	{
		cout << "1.Add Elements \n2.Display\n3. Exit\n";
		cout << "Enter choice";
		cin >> choice;
		if (choice == 1)
		{
			cout << "Enter Data:";
				cin >> d;
			l.insertdata(d);
		}
		else if (choice == 2)
		{
			
			l.display();
		}
		else if (choice == 3)
		{
			return 0;
		}
	} while (choice != 4);
	return 0;
}