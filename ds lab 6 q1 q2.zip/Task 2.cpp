#include<iostream>
using namespace std;
class node
{
public:
	int data;
	node*next;
	

};
class list
{
private:
	node*head;
public:
	list()
	{
		head = NULL;
	}
	void insertdata(int d)
	{
		node* temp = new node;
		temp->data = d;
		temp->next = NULL;
		node* curr = head;
		if (head == NULL)
		{
			head = temp;
		}
		else
		{
			while (curr->next != NULL)
			{
				curr = curr->next;
			}
			 curr->next=temp;
		}

		
	}
	void insertatbegning(int d)
	{
		node*temp = new node;
		temp->data = d;
		temp ->next = head;
		head = temp;
	}
	void deletebyvalue(int v)
	{
		node *temp = new node;
		node* curr = head;
		if (head->data == v)
		{
			temp = head;
			head = head->next;
			delete temp;
		}
		else
		{
			while ( curr->next->data==v && curr->next != NULL)
			{
				curr = curr->next;
			}
			if (curr->next == NULL)
			{
				cout << "value not found";
			}
			else
			{
				temp = curr->next;
				curr->next = temp->next;
				delete temp;
				cout << "Node deleted";
			}
		}
		
	}
	void display()
	{
		node* curr = head;
		while (curr!= NULL)
		{
			cout << curr->data<< endl;
			curr = curr->next;
		}
	}
};
int main()
{
	int choice;
	list l;
	int d;
	do
	{
		cout << "1.insert at end \n 2.insert at begning\n 3.delete\n4.Display\n5. Exit\n";
		cout << "Enter choice";
		cin >> choice;
		if (choice == 1)
		{
			cout << "Enter Data:";
				cin >> d;
			l.insertdata(d);
		}
		else if (choice == 2)
		{
			cout << "Enter Data:";
			cin >> d;
			l.insertatbegning(d);
		}
		else if (choice == 3)		
		{
			cout << "Enter value you want to delete:";
			cin >> d;
			l.deletebyvalue(d);
		}
		else if (choice == 4)
		{
			
			l.display();
		}
	} while (choice != 5);
	return 0;
}