#include <iostream>
#include <string>
using namespace std;

template <typename t>
class stack
{
    t arr[100];
    int top = -1;
public:
    void push(t x)
    {
        arr[++top] = x;
    }
    t pop()
    {
        return arr[top--];
    }
    bool isempty()
    {
        return top == -1;
    }
    t peek()
    {
        return arr[top];
    }
    int size()
    {
        return top + 1;
    }
};

class parkinglot
{
    stack<string> mycarstack;
    const int capacity = 8;
public:
    void parkcar(const string& carnumber)
    {
        if (mycarstack.size() >= capacity)
        {
            cout << "parking full! cannot park " << carnumber;
            return;
        }
        mycarstack.push(carnumber);
        cout << "car " << carnumber << " parked successfully";
    }

    void removecar(const string& carnumber)
    {
        if (mycarstack.isempty())
        {
            cout << "parking lot is empty";
            return;
        }
        stack<string> temp;
        bool found = false;
        while (!mycarstack.isempty())
        {
            string topcar = mycarstack.pop();
            if (topcar == carnumber)
            {
                found = true;
                break;
            }
            temp.push(topcar);
        }
        while (!temp.isempty())
            mycarstack.push(temp.pop());
        if (found)
            cout << "car " << carnumber << " removed";
        else
            cout << "car " << carnumber << " not found";
    }

    void viewcars()
    {
        if (mycarstack.isempty())
        {
            cout << "parking lot is empty";
            return;
        }
        stack<string> temp = mycarstack;
        cout << "cars parked (top -> bottom):";
        while (!temp.isempty())
            cout << temp.pop();
    }

    void totalcars()
    {
        cout << "total cars: " << mycarstack.size();
    }

    void searchcar(const string& carnumber)
    {
        stack<string> temp = mycarstack;
        bool found = false;
        while (!temp.isempty())
            if (temp.pop() == carnumber)
            {
                found = true;
                break;
            }
        if (found)
            cout << "car " << carnumber << " is in parking";
        else
            cout << "car " << carnumber << " not found";
    }
};

int main()
{
    parkinglot lot;
    int choice;
    string carnumber;
    do
    {
        cout << "1. park car\n2. remove car\n3. view cars\n4. total cars\n5. search car\n0. exit\nchoice: ";
        cin >> choice;
        switch (choice)
        {
        case 1:
            cout << "enter car number: ";
            cin >> carnumber;
            lot.parkcar(carnumber);
            break;
        case 2:
            cout << "enter car number: ";
            cin >> carnumber;
            lot.removecar(carnumber);
            break;
        case 3:
            lot.viewcars();
            break;
        case 4:
            lot.totalcars();
            break;
        case 5:
            cout << "enter car number: ";
            cin >> carnumber;
            lot.searchcar(carnumber);
            break;
        case 0:
            cout << "exiting...";
            break;
        default:
            cout << "invalid choice";
        }
    } while (choice != 0);
    return 0;
}