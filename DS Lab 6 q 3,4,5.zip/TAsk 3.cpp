#include<iostream>
using namespace std;
class node
{
public:
	int data;
	node* next;
};
class list
{
private :
	node* head;
public:
	list()
	{
		head = NULL;
	}
	void insertatposition()
	{
		int p, d;
		cout << "ENter Data:";
		cin >> d;
		cout << "Enter Position:";
		cin >> p;
		node* curr = head;
		node* prev = NULL;
		node* temp = new node;
		temp->data = d;
		temp->next = NULL;
		if (p == 1)
		{
			head = temp;
			return;
		}
		for (int i = 1; i < p && curr != NULL; i++)
		{
			prev = curr;
			curr = curr->next;
		}
		prev->next = temp;
		temp->next = curr;
	}
	void deletefromposition()
	{
		int p;
		cout << "Enter the position of the element you want to delete";
		cin >> p;
		node* curr = head;
		node* prev = NULL;
		
		for (int i = 1; i < p && curr != NULL; i++)
		{
			prev = curr;
			curr = curr->next;
		}
		prev->next = curr->next;
		delete curr;
		cout << "Deleted successfully"<<endl;
	}
	void search()
	{
		int v;
		int p = 1;
		cout << "Enetr the value you want to search:";
		cin >> v;
		node* curr = head;
		while (curr != NULL)
		{
			if (curr->data == v)
			{
				cout << "Value found at position :" << p<<endl;
				return;
			}
			curr = curr->next;
		}
		cout << "Value not found in the list" << endl;
	}
	void totalnodes()
	{
		int count = 0;
		node* curr = head;
		while (curr != NULL)
		{
			count++;
			curr = curr->next;
		}
		cout << "Total nodes in the are :" << count << endl;
	}
	void display()
	{
		node* curr = head;
		while (curr != NULL)
		{
			cout << curr->data<<endl;
			curr = curr->next;
		}
	}
};
int main()
{
	int c;
	list l;
	do
	{
		cout<<"\n1.Insert at Position \n2.Delete from position\n3.Search in the list\n4.No of nodes\n5.Display\n6.Exit\n";
		cout << "Enter Choice:";
		cin >> c;
		if (c == 1)
		{
			l.insertatposition();
		}
		else if (c == 2)
		{
			l.deletefromposition();
		}
		else if (c == 3)
		{
			l.search();
		}
		else if (c == 4)
		{
			l.totalnodes();
		}
		else if (c == 5)
		{
			l.display();
		}
	} while (c != 6);

	return 0;
}