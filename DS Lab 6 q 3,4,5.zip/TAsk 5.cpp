#include<iostream>
using namespace std;

class node
{
public:
    int id;
    int priority;
    node* next;
};

class list
{
private:
    node* head;

public:
    list()
    {
        head = NULL;
    }

    void addstudent()
    {
        int id, p;
        cout << "enter student id:";
        cin >> id;
        cout << "enter priority (1-high,2-medium,3-low):";
        cin >> p;

        node* temp = new node;
        temp->id = id;
        temp->priority = p;
        temp->next = NULL;

        if (head == NULL || p < head->priority)
        {
            temp->next = head;
            head = temp;
            return;
        }

        node* curr = head;
        while (curr->next != NULL && curr->next->priority <= p)
        {
            curr = curr->next;
        }

        temp->next = curr->next;
        curr->next = temp;
    }

    void removestudent()
    {
        int id;
        cout << "enter student id to remove:";
        cin >> id;

        node* curr = head;
        node* prev = NULL;

        if (head != NULL && head->id == id)
        {
            node* temp = head;
            head = head->next;
            delete temp;
            cout << "removed\n";
            return;
        }

        while (curr != NULL && curr->id != id)
        {
            prev = curr;
            curr = curr->next;
        }

        if (curr == NULL)
        {
            cout << "not found\n";
            return;
        }

        prev->next = curr->next;
        delete curr;
        cout << "removed\n";
    }

    void updatepriority()
    {
        int id, p;
        cout << "enter student id:";
        cin >> id;
        cout << "enter new priority:";
        cin >> p;

        node* curr = head;
        node* prev = NULL;

        while (curr != NULL && curr->id != id)
        {
            prev = curr;
            curr = curr->next;
        }

        if (curr == NULL)
        {
            cout << "not found\n";
            return;
        }

        if (prev == NULL)
        {
            head = curr->next;
        }
        else
        {
            prev->next = curr->next;
        }

        curr->priority = p;

        if (head == NULL || p < head->priority)
        {
            curr->next = head;
            head = curr;
            return;
        }

        node* temp = head;
        while (temp->next != NULL && temp->next->priority <= p)
        {
            temp = temp->next;
        }

        curr->next = temp->next;
        temp->next = curr;
    }

    void display()
    {
        node* curr = head;

        if (curr == NULL)
        {
            cout << "empty\n";
            return;
        }

        while (curr != NULL)
        {
            cout << "id:" << curr->id << " priority:" << curr->priority << endl;
            curr = curr->next;
        }
    }

    void countstudents()
    {
        int count = 0;
        node* curr = head;

        while (curr != NULL)
        {
            count++;
            curr = curr->next;
        }

        cout << "total: " << count << endl;
    }

    void serve()
    {
        if (head == NULL)
        {
            cout << "no students\n";
            return;
        }

        node* temp = head;
        cout << "served student id: " << temp->id << endl;
        head = head->next;
        delete temp;
    }
};

int main()
{
    list book1, book2;
    int c, b;

    do
    {
        cout << "\n1.add student\n2.remove student\n3.update priority\n4.display\n5.count\n6.serve\n7.exit\n";
        cout << "select book (1 or 2):";
        cin >> b;

        cout << "enter choice:";
        cin >> c;

        if (b == 1)
        {
            if (c == 1) book1.addstudent();
            else if (c == 2) book1.removestudent();
            else if (c == 3) book1.updatepriority();
            else if (c == 4) book1.display();
            else if (c == 5) book1.countstudents();
            else if (c == 6) book1.serve();
        }
        else if (b == 2)
        {
            if (c == 1) book2.addstudent();
            else if (c == 2) book2.removestudent();
            else if (c == 3) book2.updatepriority();
            else if (c == 4) book2.display();
            else if (c == 5) book2.countstudents();
            else if (c == 6) book2.serve();
        }

    } while (c != 7);

    return 0;
}