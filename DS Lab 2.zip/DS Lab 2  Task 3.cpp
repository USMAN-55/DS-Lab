#include<iostream>
using namespace std;
template <class T>
int linearsearch(T arr[], int size, T key)
{
	for (int i = 0; i < size; i++)
	{
		if (arr[i] == key)
		{
			return i;
		}
	}
	return -1;
}
class libraryitem
{
public:

	virtual void display() = 0;
};
class book:public libraryitem
{
protected:
	string title;
	string author;
	int pages;
	public:
		book()
		{

		}
		book(string t, string a, int p)
		{
			title = t;
			author = a;
			pages = p;
		}
		string gettitle()
		{
			return title;
		}
		string getauthor()
		{
			return author;
		}
		int getpages()
		{
			return pages;
		}
		void display()
		{
			cout << "Title:" << gettitle() << " Author :" << getauthor() << " Pages: " << getpages() << endl;
		}
		bool operator==(string t)
		{
			return title == t;
		}
};
class newspaper:public libraryitem
{
protected:
	string name;
	string date;
	string edition;
public:
	newspaper()
	{

	}
	newspaper(const string n, string d, string e)
	{
		name = n;
		date = d;
		edition = e;
	}
	string getname()
	{
		return name;
	}
	string getdate()
	{
		return date;
	}
	string getedition()
	{
		return edition;
	}
	void display()
	{
		cout << "Name:" << getname() << " Date :" << getdate() << " Edition: " << getedition()<< endl;
	}
	bool operator==(string n)
	{
		return name == n;
	}
};
class library
{
private:
	book books[10];
	newspaper newspapers[10];
	int bookcount = 0;
	int newspapercount = 0;
public:
	void addbook(book b)
	{
		books[bookcount++] = b;
	}
	void addnewspaper(newspaper n)
	{
		newspapers[newspapercount++] = n;
	}
	void displaycollection()
	{
		cout << "Books" << endl;
		for (int i = 0; i < bookcount; i++)
		{
			books[i].display();
			cout << endl;
		}
		cout << "Newspaper" << endl;
		for (int i = 0; i < newspapercount; i++)
		{
			newspapers[i].display();
			cout << endl;
		}
	}
	void sortbooks()
	{
		for (int i = 0; i < bookcount - 1; i++)
		{
			for (int j = i + 1; j < bookcount; j++)
			{
				if (books[i].getpages() > books[j].getpages())
				{
					book temp = books[i];
					books[i] = books[j];
					books[j] = temp;

				}
			}
		}
	}
	void sortnewspapers()
	{
		for (int i = 0; i <newspapercount - 1; i++)
		{
			for (int j = i + 1; j < newspapercount; j++)
			{
				if (newspapers[i].getedition() > newspapers[j].getedition())
				{
					newspaper temp = newspapers[i];
					newspapers[i] = newspapers[j];
					newspapers[j] = temp;

				}
			}
		}
	}
	book* searchbookbytitle(string title)
	{
		for (int i = 0; i < bookcount; i++)
		{
			if (books[i].gettitle() == title)
			{
				return &books[i];
			}
		}
		return NULL;
	}
	newspaper* searchnewspaperbyname(string name)
	{
		for (int i = 0; i < newspapercount; i++)
		{
			if (newspapers[i].getname() == name)
			{
				return &newspapers[i];
			}
		}
		return NULL;
	}
};

int main()
{
	
	book book1("The Catcher in the Rye", "J.D. Salinger", 277);
	book book2("To Kill a Mockingbird", "Harper Lee", 324);

	newspaper newspaper1("Washington Post", "2024-10-13", "Morning Edition");
	newspaper newspaper2("The Times", "2024-10-12", "Weekend Edition");

	library librarys;

	librarys.addbook(book1);
	librarys.addbook(book2);

	librarys.addnewspaper(newspaper1);
	librarys.addnewspaper(newspaper2);

	cout << "Before Sorting:\n";
	librarys.displaycollection();

	librarys.sortbooks();
	librarys.sortnewspapers();

	cout << "\nAfter Sorting:\n";
	librarys.displaycollection();
	book* foundbook = librarys.searchbookbytitle("The Catcher in the Rye");

	if (foundbook)
	{
		cout << "\nFound Book:\n";
		foundbook->display();
	}
	else
	{
		cout << "\nBook not found\n";
	}

	newspaper* foundnews = librarys.searchnewspaperbyname("The Times");

	if (foundnews)
	{
		cout << "\nFound Newspaper:\n";
		foundnews->display();
	}
	else
	{
		cout << "\nNewspaper not found\n";
	}

	return 0;
}