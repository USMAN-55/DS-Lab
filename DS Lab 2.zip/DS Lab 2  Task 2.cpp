#include<iostream>
using namespace std;
class employee
{
	public:
		virtual void calculatesalary() = 0;

};
class fulltime :public employee
{
private:
	float salary;
public:
	fulltime(float s)
	{
		salary = s;
	}
	void calculatesalary()
	{
		cout << "The salary of fultime employee is : " << salary << endl;
	}
};
class parttime:public employee
{
private:
	int hours;
	float rate;
public:
	parttime(int h, float r)
	{
		hours = h;
		rate = r;
	}
	void calculatesalary()
	{
		cout << "The salary of parttime employee is : " << hours * rate << endl;
	}
};
int main()
{
	fulltime f(10000);
	parttime p(12, 100);
	f.calculatesalary();
	p.calculatesalary();

	return 0;
}