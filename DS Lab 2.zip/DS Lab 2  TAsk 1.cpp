#include<iostream>
using namespace std;
class shape
{
public:
	virtual void area() = 0;

};
class circle :public shape
{
private:
	float radius;
public:
	circle(float r)
	{
		radius = r;
	}
	void area()
	{
		float a;
		a = (3.14) * (radius * radius);
		cout << "The atea of circle is : " << a << endl;
	}
};
class rectangle:public shape
{
private:
	int length;
	int width;
public:
	rectangle(int l, int w)
	{
		length = l;
		width = w;
	}
	void area()
	{
		float a;
		a = length * width;
		cout << "The atea of Rectangle is : " << a << endl;
	}
};
int main()
{
	circle c1(5);
	rectangle r1(5, 10);
	c1.area();
	r1.area();


	return 0;
}