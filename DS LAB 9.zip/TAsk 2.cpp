#include<iostream>
using namespace std;

class node
{
public:
    int songid;
    string songname;
    float duration;

    node* prev;
    node* next;
};

class playlist
{
private:
    node* head;
    node* current;

public:
    playlist()
    {
        head = NULL;
        current = NULL;
    }

    void addsong(int id, string name, float dur)
    {
        node* temp = new node;
        temp->songid = id;
        temp->songname = name;
        temp->duration = dur;
        temp->next = NULL;
        temp->prev = NULL;

        if (head == NULL)
        {
            head = temp;
            current = head;
            return;
        }

        node* curr = head;
        while (curr->next != NULL)
        {
            curr = curr->next;
        }

        curr->next = temp;
        temp->prev = curr;
    }

    void deletesong(string name)
    {
        if (head == NULL)
        {
            cout << "playlist empty\n";
            return;
        }

        node* curr = head;

        while (curr != NULL && curr->songname != name)
        {
            curr = curr->next;
        }

        if (curr == NULL)
        {
            cout << "song not found\n";
            return;
        }

        if (curr == head && curr->next == NULL)
        {
            head = NULL;
            current = NULL;
        }
        else if (curr == head)
        {
            head = head->next;
            head->prev = NULL;
        }
        else if (curr->next == NULL)
        {
            curr->prev->next = NULL;
        }
        else
        {
            curr->prev->next = curr->next;
            curr->next->prev = curr->prev;
        }

        if (current == curr)
        {
            current = head;
        }

        delete curr;
    }

    void playnext()
    {
        if (current != NULL && current->next != NULL)
        {
            current = current->next;
            cout << "now playing: " << current->songname << endl;
        }
        else
        {
            cout << "no next song\n";
        }
    }

    void playprev()
    {
        if (current != NULL && current->prev != NULL)
        {
            current = current->prev;
            cout << "now playing: " << current->songname << endl;
        }
        else
        {
            cout << "no previous song\n";
        }
    }

    void reverseplaylist()
    {
        node* curr = head;
        node* temp = NULL;

        while (curr != NULL)
        {
            temp = curr->prev;
            curr->prev = curr->next;
            curr->next = temp;
            curr = curr->prev;
        }

        if (temp != NULL)
        {
            head = temp->prev;
        }
    }

    void display()
    {
        node* curr = head;

        while (curr != NULL)
        {
            cout << curr->songid << " "
                << curr->songname << " "
                << curr->duration << endl;

            curr = curr->next;
        }
    }
};

int main()
{
    playlist p;

    p.addsong(1, "songa", 3.5);
    p.addsong(2, "songb", 4.2);
    p.addsong(3, "songc", 5.0);

    p.display();

    p.playnext();
    p.playprev();

    p.deletesong("songb");
    p.display();

    p.reverseplaylist();
    p.display();

    return 0;
}