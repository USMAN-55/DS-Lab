#include<iostream>
using namespace std;
class node
{
public:
	int data;
	node* prev;
	node* next;
};
class doubly
{
private:
	node* head=NULL;
public:
	void insertatend(int v)
	{
		node* temp = new node;
		temp->data = v;
		temp->prev = NULL;
		temp->next = NULL;
		node* curr = head;
		if (head == NULL)
		{
			insertatstart(v);
			return;
		}
		else
		{
			while (curr->next != NULL)
			{
				curr = curr->next;
			}
			curr->next = temp;
			temp->prev = curr;
			temp->next = NULL;
		}
	
	}
	void insertatstart(int v)
	{
		node* temp = new node;
		temp->data = v;
		temp->prev = NULL;
		temp->next = NULL;
		if (head == NULL)
		{
			head = temp;
			return;
		}
		else
		{
			temp->next = head;
			head->prev = temp;
			head = temp;
		}
		
	}
	void insertatposition(int v,int p)
	{
		node* temp = new node;
		temp->data = v;
		temp->prev = NULL;
		temp->next = NULL;
		if (p == 1)
		{
			insertatstart(v);
			return;
		}

		else
		{
			node* curr = head;
			for(int i=1;i<p-1;i++)
			{
				curr = curr->next;
			}
			if (curr->next == NULL)
			{
				insertatend(v);
			}
			else
			{
				temp->next = curr->next;
				curr->next->prev = temp;
				curr->next = temp;
				temp->prev = curr;
			}
			
		}
	}
	void deletefromstart()
	{
		if (head == NULL)
		{
			cout << "The list is empty ";
			return;
		}
		node* temp = head;
		head = head->next;
		head->prev = NULL;
		delete temp;
	}
	void deletefromend()
	{
		if (head == NULL)
		{
			cout << "List is empty";
			return;
		}
		node* curr = head;
		while (curr->next != NULL)
		{
			curr = curr->next;
		}
		curr->prev->next = NULL;
		delete curr;
	}
	void deletefromposition(int p)
	{
		node* curr = head;
		if (head == NULL)
		{
			cout << "List is Empty";
			return;
		}
		if (p == 1)
		{
			deletefromstart();
			return;
		}
		for (int i = 1; i < p; i++)
		{
			curr = curr->next;
		}
		if (curr->next == NULL)
		{
			deletefromend();
			return;
		}
		curr->prev->next = curr->next;
		curr->next->prev = curr->prev;
		delete curr;
	}
	void display()
	{
		node* curr = head;
		while(curr!=NULL)
			{
			cout << curr->data << " ";
			curr = curr->next;
			}
	}
	void displayreverse()
	{
		node* curr = head;
		while (curr->next != NULL)
		{
			curr = curr->next;
		}
		while (curr != NULL)
		{
			cout << curr->data << " ";
			curr = curr->prev;
		}
	}

};
int main()
{
	int c;
	doubly l;
	int v,p;
	do
	{
		cout << "\n1.Insert at start" << endl;
		cout << "2.Insert at end" << endl;
		cout << "3.Insert at position" << endl;
		cout << "4.Delete from start" << endl;
		cout << "5.Delete from end" << endl;
		cout << "6.Delete from position" << endl;
		cout << "7.Display" << endl;
		cout << "8.Reverse Dipslay" << endl;
		cout << "9.Exit" << endl;
		cout << "Enter choice";
		cin >> c;
		if (c == 1)
		{
			cout << "Enter data";
			cin >> v;
			l.insertatstart(v);
		}
		else if (c == 2)
		{
			cout << "Enter data";
			cin >> v;
			l.insertatend(v);
		}
		else if (c == 3)
		{
			cout << "Enter data";
			cin >> v;
			cout << "Enter pos";
			cin >> p;
			l.insertatposition(v,p);
		}
		else if (c == 4)
		{
			l.deletefromstart();
		}
		else if (c == 5)
		{
			l.deletefromend();
		}
		else if (c == 6)
		{
			cout << "Enter pos";
			cin >> p;
			l.deletefromposition(p);
		}
		else if (c == 7)
		{
			l.display();
		}
		else if (c == 8)
		{
			l.displayreverse();
		}
		else
		{
			cout << "INVALID CHOICE";
		}
	} while (c != 9);
	return 0;
}