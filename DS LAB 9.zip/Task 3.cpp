#include<iostream>
using namespace std;

class node
{
public:
    int playerid;
    int score;
    node* next;
};

class game
{
private:
    node* head;
    node* current;

public:
    game()
    {
        head = NULL;
        current = NULL;
    }

    void addplayer(int id, int sc)
    {
        node* temp = new node;
        temp->playerid = id;
        temp->score = sc;
        temp->next = NULL;

        if (head == NULL)
        {
            head = temp;
            temp->next = head;
            current = head;
            return;
        }

        node* curr = head;
        while (curr->next != head)
        {
            curr = curr->next;
        }

        curr->next = temp;
        temp->next = head;
    }

    void nextturn()
    {
        if (current == NULL)
        {
            cout << "no player\n";
            return;
        }

        current = current->next;
        cout << "player turn: " << current->playerid << endl;
    }

    void skipplayer()
    {
        if (current == NULL)
        {
            cout << "no player\n";
            return;
        }

        current = current->next;
        current = current->next;
        cout << "skipped to: " << current->playerid << endl;
    }

    void removeplayer(int id)
    {
        if (head == NULL)
        {
            cout << "empty game\n";
            return;
        }

        node* curr = head;
        node* prev = NULL;

        do
        {
            if (curr->playerid == id)
                break;

            prev = curr;
            curr = curr->next;

        } while (curr != head);

        if (curr->playerid != id)
        {
            cout << "player not found\n";
            return;
        }

        if (curr == head && curr->next == head)
        {
            delete curr;
            head = NULL;
            current = NULL;
            return;
        }

        if (curr == head)
        {
            node* last = head;
            while (last->next != head)
            {
                last = last->next;
            }

            head = head->next;
            last->next = head;
        }
        else
        {
            prev->next = curr->next;
        }

        if (current == curr)
        {
            current = curr->next;
        }

        delete curr;
    }

    void checkwinner()
    {
        if (head == NULL)
        {
            cout << "no players\n";
            return;
        }

        if (head->next == head)
        {
            cout << "winner: " << head->playerid << endl;
        }
    }

    void display()
    {
        if (head == NULL)
        {
            cout << "empty\n";
            return;
        }

        node* curr = head;

        do
        {
            cout << curr->playerid << " " << curr->score << endl;
            curr = curr->next;

        } while (curr != head);
    }
};

int main()
{
    game g;

    g.addplayer(1, 10);
    g.addplayer(2, 20);
    g.addplayer(3, 30);

    g.display();

    g.nextturn();
    g.skipplayer();

    g.removeplayer(2);
    g.display();

    g.checkwinner();

    return 0;
}