#include <iostream>
using namespace std;

template <class t>
void bubblesort(t a[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                swap(a[j], a[j + 1]);
            }
        }
    }
}

template <class t>
void printarray(t a[], int n) {
    for (int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

int main() {
    int intarray[5] = { 64, 25, 12, 22, 11 };
    cout << "original integer array: ";
    printarray(intarray, 5);
    bubblesort(intarray, 5);
    cout << "sorted integer array: ";
    printarray(intarray, 5);

    string stringarray[4] = { "apple", "orange", "banana", "grape" };
    cout << "original string array: ";
    printarray(stringarray, 4);
    bubblesort(stringarray, 4);
    cout << "sorted string array: ";
    printarray(stringarray, 4);

    return 0;
}
