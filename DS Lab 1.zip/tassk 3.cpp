#include <iostream>
using namespace std;

template <class t>
int binarysearch(t a[], int n, t key) {
    int low = 0, high = n - 1;
    while (low <= high) {
        int mid = (low + high) / 2;
        if (a[mid] == key) {
            return mid;
        }
        else if (a[mid] < key) {
            low = mid + 1;
        }
        else {
            high = mid - 1;
        }
    }
    return -1;
}

template <class t>
void printsearchresult(int index, t key) {
    if (index == -1) {
        cout << key << " not found" << endl;
    }
    else {
        cout << key << " found at index " << index << endl;
    }
}

int main() {
    int intarray[5] = { 11, 12, 22, 25, 64 };
    int intkey = 22;
    int intindex = binarysearch(intarray, 5, intkey);
    printsearchresult(intindex, intkey);

    float floatarray[4] = { 0.57, 1.62, 2.71, 3.14 };
    float floatkey = 2.71;
    int floatindex = binarysearch(floatarray, 4, floatkey);
    printsearchresult(floatindex, floatkey);

    string stringarray[4] = { "apple", "banana", "grape", "orange" };
    string stringkey = "grape";
    int stringindex = binarysearch(stringarray, 4, stringkey);
    printsearchresult(stringindex, stringkey);

    return 0;
}