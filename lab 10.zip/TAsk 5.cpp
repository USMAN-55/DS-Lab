#include<iostream>
using namespace std;
class node
{
public:
	int data;
	node* next;
};
class list
{
public:
	node*head;
	list()
	{
		head = NULL;
	}
	void insertatstart(int d)
	{
		node* temp = new node;
		temp->data = d;
		temp->next = NULL;
		if (head == NULL)
		{
			head = temp;
		}
		else
		{
			temp->next = head;
			head=temp;
		}
	}
	void insertatend(int d,node * c)
	{
		if (c == NULL)
		{
			cout << "NO Nodes Please insert at start" << endl;
			return;
		}
		if (c->next == NULL )
		{
			node* temp = new node;
			temp->data = d;
			temp->next = NULL;
			c->next = temp;
			return;
		}
		c = c->next;
		insertatend(d, c);
	}
	void insertatpos(int d,int p,node*c,node*pr,int i)
	{
		if (c == NULL)
		{
			cout << "Empty Linklist";
			return;
		}
		if (i==p)
		{
			node* temp = new node;
			temp->data = d;
			pr->next = temp;
			temp->next = c;
			return;
			
		}
		i++;
		pr = c;
		c = c->next;
		insertatpos(d, p, c, pr, i);
		
		
	}
	void deletefromstart()
	{
		node* temp = head;
		head = head->next;
		delete temp;
	}
	void deletefromend(node*c,node*pr)
	{
		if (c == NULL)
		{
			cout << "No LInk List ";
			return;
		}
		if (c->next== NULL)
		{
			pr->next = NULL;
			delete c;
			return;
		}
		pr = c;
		c = c->next;
		deletefromend(c,pr);
	}
	void deletefrompos(node*c,node*pr,int p,int i)
	{
		if (c == NULL)
		{
			cout << "NO LinkList";
			return;
		}
		if (p == 1)
		{
			cout << "USe dlt form start function";
			return;
		}
		if (i == p)
		{
			pr->next = c->next;
			delete c;
			return;
		}
		i++;
		pr = c;
		c = c->next;
		deletefrompos(c, pr, p, i);
	}
	void display(node*c)
	{
		if (c == NULL)
		{
			cout << "End";
			return;
		}
		cout << c->data<<" ";
		c = c->next;
		display(c);
	}

};
int main()
{
	list l;
	
	l.insertatstart(1);
	l.insertatstart(3);
	l.insertatstart(2);
	node* curr = l.head;
	l.insertatend(4, curr);
	l.insertatend(5, curr);
	node* p = NULL;
	l.insertatpos(0, 3, curr, p, 1);
	l.display(curr);
	cout << endl;
	cout << "Delete form Start" << endl;
	l.deletefromstart();
	curr = l.head;
	l.display(curr);
	cout << endl;
	l.deletefromend(curr, p);
	cout << "Delete form End" << endl;
	l.display(curr);
	cout << endl;
	cout << "Delete form Position" << endl;
	l.deletefrompos(curr, p, 4, 1);
	l.display(curr);
	return 0;
}