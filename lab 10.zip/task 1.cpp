#include<iostream>
using namespace std;
int sumofarray(int arr[],int size)
{
	if (size <=0)
	{
		return 0;
	}
	else
		return arr[size-1] + sumofarray(arr, size-1);
}
int main()
{
	int arr[5] = { 1,2,3,4,5 };
	cout<<sumofarray(arr, 5);
}