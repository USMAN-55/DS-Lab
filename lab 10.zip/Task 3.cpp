#include<iostream>
using namespace std;
int maximum(int arr[], int size,int max)
{
	if (size < 0)
	{
		return max;
	}
	else if(arr[size] > max)
	{
		max = arr[size];
	}
	return maximum(arr, size-1, max);
}
int main()
{
	int arr[5] = { 1,2,555,4,100 };
	int size=5;
	cout<<maximum(arr,size-1,arr[0]);
}