#include<iostream>
using namespace std;

class node
{
public:
    int data;
    node* next;
    node* prev;
};

class list
{
public:
    node* head;

    list()
    {
        head = NULL;
    }

    void insertatstart(int d)
    {
        if (head == NULL)
        {
            node* temp = new node;
            temp->data = d;
            temp->next = NULL;
            temp->prev = NULL;
            head = temp;
            return;
        }

        node* temp = new node;
        temp->data = d;
        temp->prev = NULL;
        temp->next = head;
        head->prev = temp;
        head = temp;
    }

    void insertatend(node* c, int d)
    {
        if (c == NULL) return;

        if (c->next == NULL)
        {
            node* temp = new node;
            temp->data = d;
            temp->next = NULL;
            temp->prev = c;
            c->next = temp;
            return;
        }

        insertatend(c->next, d);
    }

    void insertatpos(node* c, int d, int p, int i)
    {
        if (c == NULL) return;

        if (i == p)
        {
            node* temp = new node;
            temp->data = d;

            temp->next = c;
            temp->prev = c->prev;

            if (c->prev != NULL)
                c->prev->next = temp;

            c->prev = temp;
            return;
        }

        insertatpos(c->next, d, p, i + 1);
    }

    void deletefromstart()
    {
        if (head == NULL) return;

        node* temp = head;
        head = head->next;

        if (head != NULL)
            head->prev = NULL;

        delete temp;
    }

    void deletebyvalue(node* c, int val)
    {
        if (c == NULL) return;

        if (c->data == val)
        {
            if (c->prev != NULL)
                c->prev->next = c->next;
            else
                head = c->next;

            if (c->next != NULL)
                c->next->prev = c->prev;

            delete c;
            return;
        }

        deletebyvalue(c->next, val);
    }

    void deletebypos(node* c, int p, int i)
    {
        if (c == NULL) return;

        if (i == p)
        {
            if (c->prev != NULL)
                c->prev->next = c->next;
            else
                head = c->next;

            if (c->next != NULL)
                c->next->prev = c->prev;

            delete c;
            return;
        }

        deletebypos(c->next, p, i + 1);
    }

    int search(node* c, int val, int i)
    {
        if (c == NULL) return -1;

        if (c->data == val) return i;

        return search(c->next, val, i + 1);
    }

    void displayforward(node* c)
    {
        if (c == NULL) return;

        cout << c->data << " ";
        displayforward(c->next);
    }

    void displayreverse(node* c)
    {
        if (c == NULL) return;

        displayreverse(c->next);
        cout << c->data << " ";
    }

    node* gettail()
    {
        node* c = head;

        if (c == NULL) return NULL;

        while (c->next != NULL)
        {
            c = c->next;
        }

        return c;
    }

    bool ispalindrome(node* left, node* right)
    {
        if (left == NULL || right == NULL) return true;

        if (left == right || left->prev == right) return true;

        if (left->data != right->data) return false;

        return ispalindrome(left->next, right->prev);
    }
};

int main()
{
    list l;

    l.insertatstart(1);
    l.insertatstart(2);
    l.insertatstart(3);
    l.insertatstart(2);
    l.insertatstart(1);

    cout << "forward ";
    l.displayforward(l.head);
    cout << endl;

    cout << "reverse ";
    l.displayreverse(l.head);
    cout << endl;

    node* tail = l.gettail();

    if (l.ispalindrome(l.head, tail))
        cout << "palindrome";
    else
        cout << "not palindrome";

    cout << endl;

    l.deletefromstart();

    cout << "after delete ";
    l.displayforward(l.head);
    cout << endl;

    l.deletebyvalue(l.head, 2);

    cout << "after delete value ";
    l.displayforward(l.head);
    cout << endl;

    l.deletebypos(l.head, 2, 1);

    cout << "after delete pos ";
    l.displayforward(l.head);
    cout << endl;

    cout << "search 1 at pos ";
    cout << l.search(l.head, 1, 1);

    return 0;
}