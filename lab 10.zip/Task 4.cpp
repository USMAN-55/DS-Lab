#include<iostream>
using namespace std;
class node
{
public:
	int data;
	node* next;
};
class list
{
public:

	node* head;
	list()
	{
		head == NULL;
	}
	void insert(int v)
	{
		node* temp = new node;
		temp->data = v;
		temp->next = NULL;
		if (head == NULL)
		{
			head = temp;
		}
		else
		{
			node* curr = head;
			while (curr->next != NULL)
			{
				curr = curr->next;
			}
			curr->next = temp;
		}
	}
	
};
void printlist(node*h)
{
	if (h == NULL)
	{
		cout << "End";
		return;
	}
	cout << h->data << endl;
	h=h->next;
	printlist(h);
}
int main()
{
	list l;
	l.insert(1);
	l.insert(2);
	l.insert(3);
	l.insert(4);
	printlist(l.head);
}