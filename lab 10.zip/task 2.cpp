#include<iostream>
using namespace std;
bool palindrome(string arr, int start,int end)
{
	if (start >= end)
	{
		return true;
	}
	else
	{
		if (arr[start] != arr[end])
		{
			return false;
		}

	}
	return palindrome(arr, start + 1, end - 1);
}
int main()
{
	string str;
	int size;
	cout << "Enter String : ";
	cin >> str;
	cout << "Enter size:";
	cin >> size;
	if (palindrome(str, 0, size-1))
	{
		cout << "Palindrome";
	}
	else
		cout<<"Not Pllindorme";
}